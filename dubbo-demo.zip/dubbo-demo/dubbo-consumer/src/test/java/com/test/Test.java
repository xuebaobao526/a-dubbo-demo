package com.test;

import java.io.IOException;
import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Test {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] { "classpath:springmvc.xml" });

        context.start();
        //获取dsdd这个bean，根据dubbo-consumer.xml这个文件，找到id为dsdd的interface，
        // 根据这个interface在provider端找到对应的服务，通过ref找到在provider端对应的service
        DemoService demoService = (DemoService) context.getBean("dsdd");

        System.out.println(demoService.sayHello("哈哈哈"));

        try {
            System.in.read(); //按任意键结束
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
